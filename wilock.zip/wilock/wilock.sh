DEVICE=$1

sudo sendiq -s 200000 -f 434e6 -t u8 -i "$DEVICE"
sudo sendiq -s 200000 -f 315.0125e6 -t u8 -i "$DEVICE"
